 Hi Brandon, here are some sound effects I made for VolleyBox!
 
 10 move sounds: walking/running/jumping/direction change shoe squeaks?
 5 ball bouncing sounds: bouncing off floor, wall, hands, net
 5 hit sounds: hands hitting the ball
 5 smash sounds: really impactful sounds
 5 event sounds: buzzers, beeps, fouls, wins
 
 For the move sounds, they are meant to be triggered maybe 20% of the time whenever you press a new movement key or something, not necessarily played every footstep, but more like those shoe squeaks you hear in sports games on wood floors, you get them loudest when they suddenly change direction.
 
 Also, these sounds are at MAX VOLUME but in game you sould play at volume 10% to 50% volume: and mix everything together during testing. Quieter is often better.
 
 Hope you like em! =)

 ENJOY
 
 http://mcfunkypants.com/mp3/VolleyBox_SFX.zip
 